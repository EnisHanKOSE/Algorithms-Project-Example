public class TreeNode {

	private Hotel hotel;
	private TreeNode left;
	private TreeNode right;

	
	public TreeNode(Hotel newhotel) 
	{
		hotel = newhotel;
		left = null;
		right = null;
	}

	public void setHotel(Hotel hotel) {
		this.hotel = hotel;
	}

	public Hotel getHotel()
	{
		return hotel;
	}	
	public TreeNode getLeft()
	{
		return left;
	}

	public void setLeft(TreeNode newLeft)
	{
		left = newLeft;
	}

	public TreeNode getRight()
	{
		return right;
	}

	public void setRight(TreeNode newRight)
	{
		right = newRight;
	}

}