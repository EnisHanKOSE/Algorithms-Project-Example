public class Node {
	private Hotel hotel;
	public Node next;

	public Node(Hotel hotel) {
		this.hotel = hotel;
		next = null;
	}

	public Hotel getHotel() {
		return hotel;
	}

}
