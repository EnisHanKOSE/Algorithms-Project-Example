import java.util.Scanner;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Test {
public static void main(String[] args) {
	Operations o=new Operations();
    o.HoteladdL();
    Scanner scn=new Scanner(System.in);
    System.out.println("Welcome!!\nWe will help you choose the hotel that suits you best\nPlease enter your name for the start");
    String username=scn.next();
    System.out.println(username + " please enter yor age");
    int age=scn.nextInt();
    System.out.println(username+ " enter your budget");
    double budget=scn.nextDouble();
    System.out.println(username +" how many people will you stay");
    int people=scn.nextInt();
    System.out.println(username+" how long are you going to stay");
    int day=scn.nextInt();
    for (int i = 0; i < 4; i++) {
    System.out.println(username+" please choose what you want to do\n1-Show all hotels\n"
    		+ "2-Search by name\n3-Search by rate\n4-Show hotels that fit my budget");
    int key = scn.nextInt();
   if (key==1) {
		o.showHotels();
	System.out.println("Please write the hotel id you want");
	int input=scn.nextInt();
	o.searchHotelId(input);	
	o.showHotelFeaturesI(age,day,people,input);
   }
   else if(key==2) {
	   System.out.println("Please write the hotel name you want");
	   String nameee=scn.next()	;
		o.searchHotelName(age, day, people, nameee);
   }
   else if(key==3) {
	   System.out.println("Please write the hotel rate you want");
	   double rate=scn.nextDouble();
		o.searchHotelRate(age,day,people,rate);
		}
   else if(key==4) {
	 o.findforbudget(age, people, day, budget);
		    
	}
	   
   
   
  }
}
}

