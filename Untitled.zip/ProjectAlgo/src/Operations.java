public class Operations {
	BinarySearchTree B= new BinarySearchTree();
	LinkedList L= new LinkedList();
//	String[]hotelDataA = new String [10];
//
//	public void HotelsAddM(String HotelNamess,int n) {
//		String[]hotelDataM = new String [n];
//		String HotelNames =HotelNamess;
//		String[] parts = HotelNames.split("-");
//		for (int i = 0; i < hotelDataM.length; i++) {
//			hotelDataM [i]=parts[i]; 	
//		}		
//		for(int i = 0; i < hotelDataM.length; i++)
//		   {
//		
//		         System.out.println(hotelDataM[i]);
//		      }
//		   }
//	
	
//	public void HotelsAddA() {
//		Data H= new Data();
//		String[] parts = H.toString().split("-");
//		for (int i = 0; i < hotelDataA.length; i++) {
//			hotelDataA [i]=parts[i]; 
//		}		
////		for(int i = 0; i < hotelDataA.length; i++)
////		   {
////		
////		         System.out.println(hotelDataA[i][0]);
////		         System.out.println(hotelDataA[i][1]);
////		      }
////		      System.out.println();
//	}
//	public void showHotels() {
//		for(int i = 0; i < hotelDataA.length; i++)
//			   {			
//			         System.out.println(hotelDataA[i]);
//			      }
//	}
//	public void search(String i) {
//		for (int j = 0; j < hotelDataA.length; j++) {
//			if(hotelDataA [j][0]==String.valueOf(i)){
//System.out.println(hotelDataA [j][0].charAt(0)==i);		
//			}
//else {
//	System.out.println("bulunamadı");
//}
//			}
//		String[] parts = i.split(" ");
//		int a=0;
//
//		while (hotelDataA [a]!=parts[0]) {
//			a++;
//		}
//		System.out.println(parts[0]);
//		if (hotelDataA [a]==parts[0]) {
//			System.out.println(hotelDataA [a]);
//			a=0;
//		}
//		else {
//			a++;
//			System.err.println("error");
//		}
//		}
//	public String getHotelInfo(int i) {
//		return "Id:"+(hotel.get(i).getId()+1)+"--Name:"+hotel.get(i).getName();
//	}
	public void showHotels() {
		L.printData();	
	}
	public void searchHotelId(int i) {
		L.searchName(B.search(i));
	}
	public void searchHotelRate(int a,int d,int p,double rate) {
		showHotelFeaturesR(a,d,p,rate);
	}
	public void sortHotelN() {
	}
	public void searchHotelName(int a,int d,int p,String namee) {
		showHotelFeaturesN(a,d,p,namee);
	}
	public void showHotelFeaturesN(int a,int d,int p,String name){
		L.HotelFeaturesName(d,p,name);
		if(a<35) {
			System.out.println("The places we recommend for you are; pubs, cafes...");
		}
		else
		System.out.println("The places we recommend for you are; museums, theaters...");
	}
	public void showHotelFeaturesI(int a,int d,int p,int id) {
		L.HotelFeaturesId(d,p,id);
		if(a<35) {
			System.out.println("The places we recommend for you are; pubs, cafes...");
		}
		else
		System.out.println("The places we recommend for you are; museums, theaters...");
	}
	public void showHotelFeaturesR(int a,int d,int p,double r) {
		L.HotelFeaturesRate(d,p,r);
		if(a<35) {
			System.out.println("The places we recommend for you are; pubs, cafes...");
		}
		else
		System.out.println("The places we recommend for you are; museums, theaters...");
	
	}
	public void findforbudget(int a,int p,int d,double b) {
		L.FindHotelsForBudget(p, d, b);
		if(a<35) {
			System.out.println("The places we recommend for you are; pubs, cafes...");
		}
		else
		System.out.println("The places we recommend for you are; museums, theaters...");
	}
	public void findPrice(int id,int p,int d) {
		L.findHotelPrice(id, p, d);
	}
//	public void sortHotelR() {
//		L.sortList();
//	}
	public void HoteladdL() {
		L.addHotel(L.Aquamarine);
		L.addHotel(L.Drizzle);
		L.addHotel(L.Iceberg);
		L.addHotel(L.Light);
		L.addHotel(L.Nostalgia);
		L.addHotel(L.Onyx);
		L.addHotel(L.Oriental);
		L.addHotel(L.Riverside);
		L.addHotel(L.Stardust);
		L.addHotel(L.Winter);
	}
	public void HoteladdB() {
		B.insert(L.Aquamarine);
		B.insert(L.Drizzle);
		B.insert(L.Iceberg);
		B.insert(L.Light);
		B.insert(L.Nostalgia);
		B.insert(L.Onyx);
		B.insert(L.Oriental);
		B.insert(L.Riverside);
		B.insert(L.Stardust);
		B.insert(L.Winter);
	}
	public void searchHotelB(int i) {
		B.search(i);
	}
}