
public class Hotel {
	private String name;
	private int id;
	private double rate;
	private double priceCoefficient;
	private boolean pool;
	private boolean breakfast;
	private boolean freeInternet;
	private boolean airConditioner;
	private boolean parkingLot;
	private boolean beach;
	private boolean freeEquipment;
	private boolean fireplace;   
	public Hotel(String name, int id, double rate, double priceCoefficient, boolean pool, boolean breakfast,
			boolean freeInternet, boolean airConditioner, boolean parkingLot, boolean beach, boolean freeEquipment,
			boolean fireplace) {
		super();
		this.name = name;
		this.id = id;
		this.rate = rate;
		this.priceCoefficient = priceCoefficient;
		this.pool = pool;
		this.breakfast = breakfast;
		this.freeInternet = freeInternet;
		this.airConditioner = airConditioner;
		this.parkingLot = parkingLot;
		this.beach = beach;
		this.freeEquipment = freeEquipment;
		this.fireplace = fireplace;
	}
	public double getRate() {
		return rate;
	}

	public void setRate(double rate) {
		this.rate = rate;
	}

	public double getPriceCoefficient() {
		return priceCoefficient;
	}

	public void setPriceCoefficient(double priceCoefficient) {
		this.priceCoefficient = priceCoefficient;
	}

	public boolean isPool() {
		return pool;
	}

	public void setPool(boolean pool) {
		this.pool = pool;
	}

	public boolean isBreakfast() {
		return breakfast;
	}

	public void setBreakfast(boolean breakfast) {
		this.breakfast = breakfast;
	}

	public boolean isFreeInternet() {
		return freeInternet;
	}

	public void setFreeInternet(boolean freeInternet) {
		this.freeInternet = freeInternet;
	}

	public boolean isAirConditioner() {
		return airConditioner;
	}

	public void setAirConditioner(boolean airConditioner) {
		this.airConditioner = airConditioner;
	}

	public boolean isParkingLot() {
		return parkingLot;
	}

	public void setParkingLot(boolean parkingLot) {
		this.parkingLot = parkingLot;
	}

	public boolean isBeach() {
		return beach;
	}

	public void setBeach(boolean beach) {
		this.beach = beach;
	}

	public boolean isFreeEquipment() {
		return freeEquipment;
	}

	public void setFreeEquipment(boolean freeEquipment) {
		this.freeEquipment = freeEquipment;
	}

	public boolean isFireplace() {
		return fireplace;
	}

	public void setFireplace(boolean fireplace) {
		this.fireplace = fireplace;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
    public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	
	
public String toString() {
	return "Name: "+ name +" id: "+id;
}
}
