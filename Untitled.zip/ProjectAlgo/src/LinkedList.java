public class LinkedList {
		private Node root;
		private int size;
		public int baseprice=10;
		public LinkedList() {
			root = null;
			size = 0;
		}
		public void addHotel(Hotel hotel) {
			Node node = new Node(hotel);
			if (root == null)
				root = node;
			else { // if there exist some previous MyNode instancess
				Node currentNode = root;
				while (currentNode.next != null)
					currentNode = currentNode.next;
				currentNode.next = node;
			}
		}
		public void searchRate(double rate) {
			Node currentNode = root;
			while (currentNode != null) {
				if (Math.round(currentNode.getHotel().getRate()) == Math.round(rate)) 
						System.out.println(currentNode.getHotel());				
						currentNode = currentNode.next;
			}
		}
		public void searchId(int id) {
			Node currentNode = root;
			while (currentNode != null) {
				if (currentNode.getHotel().getId() == id) 
						System.out.println(currentNode.getHotel());				
						currentNode = currentNode.next;
			}
		}

		public void printData() {
			Node currentNode = root;
			while (currentNode != null) {
				System.out.println(currentNode.getHotel());
				currentNode = currentNode.next;
			}
		}
	Hotel Light= new Hotel("Light",123, 10, 6.6, true, true, true, true, true, true, true, true);
	Hotel Oriental=new Hotel("Oriental",234, 9.5, 6.3, true, true, true, true, true, true, true, false);
	Hotel Onyx=new Hotel("Onyx",345, 9, 6, true, true, true, true, false, true, false, false);
	Hotel Aquamarine=new Hotel("Aquamarine",456, 8.5, 5.6, true, true, true, true, true, true, false, false);
	Hotel Riverside=new Hotel("Riverside",567, 8, 5.3, true, true, true, false, true, true, false, false);
	Hotel Winter=new Hotel("Winter",678, 7.5, 5, false, true, true, false, true, false, true, true);
	Hotel Iceberg=new Hotel("Iceberg",789, 7, 4.6, false, true, true, false, true, false, true, true);
	Hotel Stardust=new Hotel("Stardust",8910, 6.5, 4.3, false, true, true, false, true, true, false, false);
	Hotel Nostalgia=new Hotel("Nostalgia",91011, 6, 4, false, true, true, false, false, false, false, false);
	Hotel Drizzle=new Hotel("Drizzle",101112, 5.5, 3.6, false, true, true, false, false, false, false, false);
//	public void addHotel(Hotel hotel) {
//		Node node = new Node(hotel);
//		if (root == null)
//			root = node;
//		else { // if there exist some previous MyNode instancess
//			Node currentNode = root;
//			while (currentNode.next != null)
//				currentNode = currentNode.next;
//			    currentNode.next = node;
//		}
//	}
	public void FindHotelsForBudget(int people,int day,double budget) {
		Node currentNode = root;
		while (currentNode != null) {
			if(baseprice*people*day*currentNode.getHotel().getPriceCoefficient()<budget) {
			System.out.println(currentNode.getHotel().getName()+" is suits you.");
			   if(currentNode.getHotel().getRate()>8) {
				System.out.println("The rental car brands we recommend for you are; Mercedes, BMW, Audi");
			   }
			   else
		       System.out.println("The rental car brands we recommend for you are; Renault,Volkswagen,Skoda");
			
			}
				currentNode = currentNode.next;
			
		
	}
	}
	public void findHotelPrice(int id,int p,int d) {
		Node currentNode = root;
		while (currentNode != null) {
			if (currentNode.getHotel().getId() == id) 
					System.out.println(currentNode.getHotel().getPriceCoefficient()*p*d*baseprice);				
			currentNode = currentNode.next;
		
	
		}
	}
	public void HotelFeaturesName(int d,int p,String name) {
		Node currentNode = root;
		while (currentNode != null) {
			 if (currentNode.getHotel().getName().toLowerCase().compareTo(name.toLowerCase())==0) {
				   System.out.println("Hotel info:\nName  "+currentNode.getHotel().getName()+"--Id:"+currentNode.getHotel().getId()+"--Rate:"
							+currentNode.getHotel().getRate()+"--Price Coefficient:" +currentNode.getHotel().getPriceCoefficient());
					   if (currentNode.getHotel().isPool()==true) 
						System.out.println("Has pool");
						else 
							System.out.println("No pool");
					   if (currentNode.getHotel().isBreakfast()==true) 
						System.out.println("Has breakfast");
						else 
							System.out.println("No breakfast");
					   if (currentNode.getHotel().isFreeInternet()==true) 
						System.out.println("Has Free Internet");
						else 
							System.out.println("No Free Internet");
					   if (currentNode.getHotel().isAirConditioner()==true) 
						System.out.println("Has Air Conditioner");
						else 
							System.out.println("No Air Conditioner");
					   if (currentNode.getHotel().isParkingLot()==true) 
						System.out.println("Has Parking Lot");
						else 
							System.out.println("No Parking Lot");
					   if (currentNode.getHotel().isBeach()==true) 
						System.out.println("Has Beach");
						else 
							System.out.println("No Beach");
					   if (currentNode.getHotel().isFreeEquipment()==true) 
						System.out.println("Has Free Equipment");
						else 
							System.out.println("No Free Equipment");
					   if (currentNode.getHotel().isFireplace()==true) 
						System.out.println("Has Fireplace");
						else 
							System.out.println("No Fireplace");
						System.out.println(currentNode.getHotel().getPriceCoefficient()*p*d*baseprice);				
						}
						currentNode = currentNode.next;

			 }
		}
	public void HotelFeaturesRate(int d,int p,double rate) {
		double ratee=Math.round(rate);
		Node currentNode = root;
		while (currentNode != null) {
			 if ( Math.round(currentNode.getHotel().getRate()) == ratee) {
				   System.out.println("Hotel info:\nName  "+currentNode.getHotel().getName()+"--Id:"+currentNode.getHotel().getId()+"--Rate:"
							+currentNode.getHotel().getRate()+"--Price Coefficient:" +currentNode.getHotel().getPriceCoefficient());
					   if (currentNode.getHotel().isPool()==true) 
						System.out.println("Has pool");
						else 
							System.out.println("No pool");
					   if (currentNode.getHotel().isBreakfast()==true) 
						System.out.println("Has breakfast");
						else 
							System.out.println("No breakfast");
					   if (currentNode.getHotel().isFreeInternet()==true) 
						System.out.println("Has Free Internet");
						else 
							System.out.println("No Free Internet");
					   if (currentNode.getHotel().isAirConditioner()==true) 
						System.out.println("Has Air Conditioner");
						else 
							System.out.println("No Air Conditioner");
					   if (currentNode.getHotel().isParkingLot()==true) 
						System.out.println("Has Parking Lot");
						else 
							System.out.println("No Parking Lot");
					   if (currentNode.getHotel().isBeach()==true) 
						System.out.println("Has Beach");
						else 
							System.out.println("No Beach");
					   if (currentNode.getHotel().isFreeEquipment()==true) 
						System.out.println("Has Free Equipment");
						else 
							System.out.println("No Free Equipment");
					   if (currentNode.getHotel().isFireplace()==true) 
						System.out.println("Has Fireplace");
						else 
							System.out.println("No Fireplace");
						System.out.println(currentNode.getHotel().getPriceCoefficient()*p*d*baseprice);				
						}
						currentNode = currentNode.next;

			 }
		}
	public void HotelFeaturesId(int d,int p,int id) {
		Node currentNode = root;
		while (currentNode != null) {
		 if ((currentNode.getHotel().getId() == id)){	
		    System.out.println("Hotel info:\nName  "+currentNode.getHotel().getName()+"--Id:"+currentNode.getHotel().getId()+"--Rate:"
				+currentNode.getHotel().getRate()+"--Price Coefficient:" +currentNode.getHotel().getPriceCoefficient());
		   if (currentNode.getHotel().isPool()==true) 
			System.out.println("Has pool");
			else 
				System.out.println("No pool");
		   if (currentNode.getHotel().isBreakfast()==true) 
			System.out.println("Has breakfast");
			else 
				System.out.println("No breakfast");
		   if (currentNode.getHotel().isFreeInternet()==true) 
			System.out.println("Has Free Internet");
			else 
				System.out.println("No Free Internet");
		   if (currentNode.getHotel().isAirConditioner()==true) 
			System.out.println("Has Air Conditioner");
			else 
				System.out.println("No Air Conditioner");
		   if (currentNode.getHotel().isParkingLot()==true) 
			System.out.println("Has Parking Lot");
			else 
				System.out.println("No Parking Lot");
		   if (currentNode.getHotel().isBeach()==true) 
			System.out.println("Has Beach");
			else 
				System.out.println("No Beach");
		   if (currentNode.getHotel().isFreeEquipment()==true) 
			System.out.println("Has Free Equipment");
			else 
				System.out.println("No Free Equipment");
		   if (currentNode.getHotel().isFireplace()==true) 
			System.out.println("Has Fireplace");
			else 
				System.out.println("No Fireplace");
			System.out.println(currentNode.getHotel().getPriceCoefficient()*p*d*baseprice);				
			}
			currentNode = currentNode.next;

	}
	}
public void searchName(String name) {
	Node currentNode = root;
	while (currentNode != null) {
		if (currentNode.getHotel().getName().toLowerCase().compareTo(name.toLowerCase())==0) 
				System.out.println(currentNode.getHotel().getName()+" selected.");	
		currentNode = currentNode.next;
		
		
				}
}
//	public void searchId(int id) {
//		// Naive Solution - without optimization
////		MyNode currentNode = root;
////		while(currentNode != null) {
////			Student student = currentNode.getStudent();
////			if(student.getGpa() > gpa)
////				System.out.println(student);
////			
////			currentNode = currentNode.next;
////		}
//
//		// Optimized Solution:
//		Node currentNode = root;
//		while (currentNode != null) {
//			if (currentNode.getHotel().getId() == id) 
//					System.out.println(currentNode.getHotel().getName()+" selected.");				
//					currentNode = currentNode.next;
//		}
//	}
//	 public void sortList()
//	    {
//	  
//	        // Node current will point to head
//	        Node current = root, index = null;
//	  
//	        double temp;
//	  
//	        if (root == null) {
//	            return;
//	        }
//	        else {
//	            while (current != null) {
//	                // Node index will point to node next to
//	                // current
//	                index = current.next;
//	  
//	                while (index != null) {
//	                    // If current node's data is greater
//	                    // than index's node data, swap the data
//	                    // between them
//	                    if (current.getHotel().getRate() > index.getHotel().getRate()) {
//	                        temp = current.getHotel().getRate();
////	                        current.rate = index.rate;
////	                        index.rate = temp;
//	                    }
//	  
//	                    index = index.next;
//	                }
//	                current = current.next;
//	            }
//	        }
//	    }
//}

//	public void searchRate(double rate) {
//		Node currentNode = root;
//		while (currentNode != null) {
//			if (Math.round(currentNode.getHotel().getRate()) == Math.round(rate)) 
//					System.out.println(currentNode.getHotel());				
//					currentNode = currentNode.next;
//		}
//	}
//	public void printData() {
//
//		// Naive Solution - without optimization:
//
////		MyNode currentNode = root;
////		
////		while(currentNode != null) {
////			Student student = currentNode.getStudent();
////			System.out.println(student);
////			
////			currentNode = currentNode.next;
////		}
//
//		// Optimized Solution:
//		Node currentNode = root;
//
//		while (currentNode != null) {
//			System.out.println(currentNode.getHotel());
//			currentNode = currentNode.next;
//		}
//
//	}
//
//}
}